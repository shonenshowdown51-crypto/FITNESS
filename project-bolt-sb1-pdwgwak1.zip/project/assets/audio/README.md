# Audio Assets

## Required Audio File

Please place your audio file here:

- **Filename:** `dark_aria_solo_levelin.mp3`
- **Location:** `/assets/audio/dark_aria_solo_levelin.mp3`
- **Purpose:** Background music for level-up moments

### How to Add:

1. Download or prepare your `dark_aria_solo_levelin.mp3` file
2. Place it in this directory (`assets/audio/`)
3. The app will automatically use it for the level-up music feature

The music player is integrated with a toggle button in the Character screen, allowing users to turn background music on or off.
