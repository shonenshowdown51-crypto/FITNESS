import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withRepeat,
  withSequence,
  Easing,
  withTiming,
} from 'react-native-reanimated';
import { useAuth } from '@/contexts/AuthContext';
import { colors, calculateXPForLevel } from '@/constants/theme';
import { LogOut, Music, Music as MusicOff, Flame, Zap } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { Audio } from 'expo-av';

const { width } = Dimensions.get('window');

export default function CharacterScreen() {
  const { profile, refreshProfile, signOut } = useAuth();
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showLevelUp, setShowLevelUp] = useState(false);

  const scale = useSharedValue(1);
  const glowOpacity = useSharedValue(0.5);
  const levelUpScale = useSharedValue(0);
  const levelUpOpacity = useSharedValue(0);

  useEffect(() => {
    scale.value = withRepeat(
      withSequence(
        withTiming(1.05, { duration: 1000, easing: Easing.inOut(Easing.ease) }),
        withTiming(1, { duration: 1000, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      false
    );

    glowOpacity.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
        withTiming(0.5, { duration: 1500, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      false
    );

    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: glowOpacity.value,
  }));

  const levelUpAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: levelUpScale.value }],
    opacity: levelUpOpacity.value,
  }));

  const toggleMusic = async () => {
    if (!profile) return;

    try {
      if (isPlaying && sound) {
        await sound.stopAsync();
        setIsPlaying(false);
      } else {
        if (!sound) {
          try {
            const { sound: newSound } = await Audio.Sound.createAsync(
              require('@/assets/audio/dark_aria_solo_levelin.mp3'),
              { shouldPlay: true, isLooping: true }
            );
            setSound(newSound);
            setIsPlaying(true);
          } catch (audioError) {
            console.error('Audio file not found. Please add dark_aria_solo_levelin.mp3 to assets/audio/');
            return;
          }
        } else {
          await sound.playAsync();
          setIsPlaying(true);
        }
      }

      await supabase
        .from('profiles')
        .update({ music_enabled: !isPlaying })
        .eq('id', profile.id);

      await refreshProfile();
    } catch (error) {
      console.error('Error toggling music:', error);
    }
  };

  const handleSignOut = async () => {
    if (sound) {
      await sound.stopAsync();
      await sound.unloadAsync();
      setSound(null);
    }
    await signOut();
  };

  if (!profile) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  const xpNeeded = calculateXPForLevel(profile.level);
  const xpProgress = (profile.current_xp / xpNeeded) * 100;

  return (
    <LinearGradient colors={[colors.background, colors.backgroundSecondary]} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.musicButton} onPress={toggleMusic}>
            {isPlaying ? (
              <Music size={24} color={colors.neonBlue} />
            ) : (
              <MusicOff size={24} color={colors.textSecondary} />
            )}
          </TouchableOpacity>
          <TouchableOpacity style={styles.logoutButton} onPress={handleSignOut}>
            <LogOut size={24} color={colors.danger} />
          </TouchableOpacity>
        </View>

        <View style={styles.profileCard}>
          <LinearGradient
            colors={[colors.card, colors.cardHighlight]}
            style={styles.cardGradient}>
            <Animated.View style={[styles.levelBadge, animatedStyle]}>
              <Animated.View style={[styles.levelGlow, glowStyle]} />
              <Text style={styles.levelLabel}>LEVEL</Text>
              <Text style={styles.levelNumber}>{profile.level}</Text>
            </Animated.View>

            <Text style={styles.username}>{profile.username}</Text>
            <Text style={styles.title}>HUNTER</Text>

            <View style={styles.streakContainer}>
              <Flame size={20} color={colors.warning} />
              <Text style={styles.streakText}>{profile.daily_streak} Day Streak</Text>
            </View>
          </LinearGradient>
        </View>

        <View style={styles.xpCard}>
          <Text style={styles.xpLabel}>EXPERIENCE POINTS</Text>
          <View style={styles.xpBarContainer}>
            <View style={styles.xpBar}>
              <LinearGradient
                colors={[colors.neonBlue, colors.neonPurple]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.xpFill, { width: `${xpProgress}%` }]}
              />
            </View>
            <Text style={styles.xpText}>
              {profile.current_xp} / {xpNeeded} XP
            </Text>
          </View>
        </View>

        <View style={styles.statsContainer}>
          <Text style={styles.sectionTitle}>STATS</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <LinearGradient
                colors={[colors.card, colors.cardHighlight]}
                style={styles.statGradient}>
                <Zap size={32} color={colors.neonBlue} />
                <Text style={styles.statValue}>{profile.strength}</Text>
                <Text style={styles.statLabel}>STRENGTH</Text>
              </LinearGradient>
            </View>

            <View style={styles.statCard}>
              <LinearGradient
                colors={[colors.card, colors.cardHighlight]}
                style={styles.statGradient}>
                <Zap size={32} color={colors.neonPurple} />
                <Text style={styles.statValue}>{profile.endurance}</Text>
                <Text style={styles.statLabel}>ENDURANCE</Text>
              </LinearGradient>
            </View>

            <View style={styles.statCard}>
              <LinearGradient
                colors={[colors.card, colors.cardHighlight]}
                style={styles.statGradient}>
                <Zap size={32} color={colors.neonPink} />
                <Text style={styles.statValue}>{profile.agility}</Text>
                <Text style={styles.statLabel}>AGILITY</Text>
              </LinearGradient>
            </View>
          </View>
        </View>

        <View style={styles.totalXpCard}>
          <Text style={styles.totalXpLabel}>TOTAL XP EARNED</Text>
          <Text style={styles.totalXpValue}>{profile.total_xp.toLocaleString()}</Text>
        </View>
      </ScrollView>

      {showLevelUp && (
        <Animated.View style={[styles.levelUpOverlay, levelUpAnimatedStyle]}>
          <LinearGradient
            colors={['rgba(0, 212, 255, 0.1)', 'rgba(168, 85, 247, 0.1)']}
            style={styles.levelUpContent}>
            <Text style={styles.levelUpText}>LEVEL UP!</Text>
            <Text style={styles.levelUpNumber}>{profile.level}</Text>
          </LinearGradient>
        </Animated.View>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  musicButton: {
    padding: 12,
    backgroundColor: colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  logoutButton: {
    padding: 12,
    backgroundColor: colors.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.danger,
  },
  loadingText: {
    color: colors.textPrimary,
    fontSize: 18,
    textAlign: 'center',
  },
  profileCard: {
    marginBottom: 24,
  },
  cardGradient: {
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  levelBadge: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: colors.neonBlue,
  },
  levelGlow: {
    position: 'absolute',
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: colors.neonBlue,
    opacity: 0.3,
  },
  levelLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    letterSpacing: 2,
  },
  levelNumber: {
    fontSize: 48,
    fontWeight: 'bold',
    color: colors.neonBlue,
  },
  username: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  title: {
    fontSize: 14,
    color: colors.neonPurple,
    letterSpacing: 4,
    marginBottom: 16,
  },
  streakContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: colors.background,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.warning,
  },
  streakText: {
    color: colors.warning,
    fontSize: 14,
    fontWeight: 'bold',
  },
  xpCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.neonPurple,
  },
  xpLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    letterSpacing: 2,
    marginBottom: 12,
  },
  xpBarContainer: {
    gap: 8,
  },
  xpBar: {
    height: 24,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    overflow: 'hidden',
  },
  xpFill: {
    height: '100%',
    borderRadius: 12,
  },
  xpText: {
    fontSize: 14,
    color: colors.textPrimary,
    textAlign: 'center',
    fontWeight: '600',
  },
  statsContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    color: colors.textSecondary,
    letterSpacing: 3,
    marginBottom: 16,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
  },
  statGradient: {
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  statValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 10,
    color: colors.textSecondary,
    letterSpacing: 1,
    marginTop: 4,
  },
  totalXpCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  totalXpLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    letterSpacing: 2,
    marginBottom: 8,
  },
  totalXpValue: {
    fontSize: 36,
    fontWeight: 'bold',
    color: colors.neonBlue,
  },
  levelUpOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
  },
  levelUpContent: {
    padding: 48,
    borderRadius: 24,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.neonBlue,
  },
  levelUpText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.neonBlue,
    letterSpacing: 4,
    marginBottom: 16,
  },
  levelUpNumber: {
    fontSize: 72,
    fontWeight: 'bold',
    color: colors.neonPurple,
  },
});
