import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/contexts/AuthContext';
import { colors, EXERCISE_XP, EXERCISE_NAMES, calculateXPForLevel, calculateLevel } from '@/constants/theme';
import { Dumbbell, Plus, X, Trophy } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withSequence,
  runOnJS,
} from 'react-native-reanimated';

type ExerciseType = 'push_ups' | 'pull_ups' | 'sit_ups' | 'leg_raises' | 'plank';

export default function TrainScreen() {
  const { profile, refreshProfile } = useAuth();
  const [selectedExercise, setSelectedExercise] = useState<ExerciseType | null>(null);
  const [quantity, setQuantity] = useState('');
  const [loading, setLoading] = useState(false);
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [newLevel, setNewLevel] = useState(0);

  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const triggerLevelUpAnimation = (level: number) => {
    setNewLevel(level);
    setShowLevelUp(true);
    scale.value = withSequence(
      withSpring(1.2),
      withSpring(1)
    );
    setTimeout(() => {
      setShowLevelUp(false);
    }, 3000);
  };

  const logExercise = async () => {
    if (!selectedExercise || !quantity || !profile) return;

    const qty = parseInt(quantity);
    if (isNaN(qty) || qty <= 0) {
      return;
    }

    setLoading(true);

    try {
      const xpPerUnit = EXERCISE_XP[selectedExercise];
      const xpEarned = xpPerUnit * qty;

      const { error: exerciseError } = await supabase.from('exercises_log').insert({
        user_id: profile.id,
        exercise_type: selectedExercise,
        quantity: qty,
        xp_earned: xpEarned,
      });

      if (exerciseError) throw exerciseError;

      const newTotalXP = profile.total_xp + xpEarned;
      const { level: calculatedLevel, currentXP } = calculateLevel(newTotalXP);

      const statIncrease = Math.floor(calculatedLevel / 5) - Math.floor(profile.level / 5);

      let updates: any = {
        total_xp: newTotalXP,
        level: calculatedLevel,
        current_xp: currentXP,
      };

      if (statIncrease > 0) {
        updates.strength = profile.strength + statIncrease;
        updates.endurance = profile.endurance + statIncrease;
        updates.agility = profile.agility + statIncrease;
      }

      const today = new Date().toISOString().split('T')[0];
      const lastActivity = profile.last_activity_date;

      if (lastActivity !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];

        if (lastActivity === yesterdayStr) {
          updates.daily_streak = profile.daily_streak + 1;
        } else if (lastActivity !== today) {
          updates.daily_streak = 1;
        }
        updates.last_activity_date = today;
      }

      const { error: profileError } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', profile.id);

      if (profileError) throw profileError;

      const statsField = `total_${selectedExercise}` as const;
      const { data: currentStats } = await supabase
        .from('user_stats')
        .select('*')
        .eq('user_id', profile.id)
        .maybeSingle();

      if (currentStats) {
        const { error: statsError } = await supabase
          .from('user_stats')
          .update({
            [statsField]: (currentStats[statsField] || 0) + qty,
          })
          .eq('user_id', profile.id);

        if (statsError) throw statsError;
      }

      const { error: questError } = await supabase.rpc('update_quest_progress', {
        p_user_id: profile.id,
        p_exercise_type: selectedExercise,
        p_quantity: qty,
      });

      await refreshProfile();

      if (calculatedLevel > profile.level) {
        triggerLevelUpAnimation(calculatedLevel);
      }

      setSelectedExercise(null);
      setQuantity('');
    } catch (error) {
      console.error('Error logging exercise:', error);
    } finally {
      setLoading(false);
    }
  };

  const exercises: { type: ExerciseType; icon: string }[] = [
    { type: 'push_ups', icon: '💪' },
    { type: 'pull_ups', icon: '🏋️' },
    { type: 'sit_ups', icon: '🧘' },
    { type: 'leg_raises', icon: '🦵' },
    { type: 'plank', icon: '⏱️' },
  ];

  return (
    <LinearGradient colors={[colors.background, colors.backgroundSecondary]} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Dumbbell size={32} color={colors.neonBlue} />
          <Text style={styles.headerTitle}>TRAINING GROUND</Text>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoText}>
            Complete exercises to gain XP and level up your character!
          </Text>
        </View>

        <Text style={styles.sectionTitle}>SELECT EXERCISE</Text>

        <View style={styles.exerciseGrid}>
          {exercises.map((exercise) => (
            <TouchableOpacity
              key={exercise.type}
              style={styles.exerciseCard}
              onPress={() => setSelectedExercise(exercise.type)}>
              <LinearGradient
                colors={[colors.card, colors.cardHighlight]}
                style={styles.exerciseGradient}>
                <Text style={styles.exerciseIcon}>{exercise.icon}</Text>
                <Text style={styles.exerciseName}>{EXERCISE_NAMES[exercise.type]}</Text>
                <Text style={styles.exerciseXP}>
                  {EXERCISE_XP[exercise.type]} XP{exercise.type === 'plank' ? '/sec' : ''}
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <Modal
        visible={selectedExercise !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setSelectedExercise(null)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {selectedExercise && EXERCISE_NAMES[selectedExercise]}
              </Text>
              <TouchableOpacity onPress={() => setSelectedExercise(null)}>
                <X size={24} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>

            <Text style={styles.modalLabel}>
              {selectedExercise === 'plank' ? 'Seconds' : 'Repetitions'}
            </Text>
            <TextInput
              style={styles.input}
              value={quantity}
              onChangeText={setQuantity}
              placeholder="0"
              placeholderTextColor={colors.textSecondary}
              keyboardType="number-pad"
            />

            {quantity && selectedExercise && (
              <View style={styles.xpPreview}>
                <Trophy size={20} color={colors.neonBlue} />
                <Text style={styles.xpPreviewText}>
                  +{parseInt(quantity || '0') * EXERCISE_XP[selectedExercise]} XP
                </Text>
              </View>
            )}

            <TouchableOpacity
              style={[styles.logButton, loading && styles.logButtonDisabled]}
              onPress={logExercise}
              disabled={loading || !quantity}>
              {loading ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <>
                  <Plus size={20} color={colors.background} />
                  <Text style={styles.logButtonText}>LOG EXERCISE</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {showLevelUp && (
        <Animated.View style={[styles.levelUpOverlay, animatedStyle]}>
          <LinearGradient
            colors={['rgba(0, 212, 255, 0.2)', 'rgba(168, 85, 247, 0.2)']}
            style={styles.levelUpContent}>
            <Text style={styles.levelUpText}>LEVEL UP!</Text>
            <Text style={styles.levelUpNumber}>{newLevel}</Text>
            <Text style={styles.levelUpSubtext}>YOU'VE BECOME STRONGER!</Text>
          </LinearGradient>
        </Animated.View>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    letterSpacing: 2,
  },
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: colors.neonPurple,
  },
  infoText: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 20,
  },
  sectionTitle: {
    fontSize: 14,
    color: colors.textSecondary,
    letterSpacing: 3,
    marginBottom: 16,
    fontWeight: 'bold',
  },
  exerciseGrid: {
    gap: 16,
  },
  exerciseCard: {
    marginBottom: 8,
  },
  exerciseGradient: {
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  exerciseIcon: {
    fontSize: 32,
    marginRight: 16,
  },
  exerciseName: {
    flex: 1,
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  exerciseXP: {
    fontSize: 16,
    color: colors.neonBlue,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 24,
    borderWidth: 2,
    borderColor: colors.neonBlue,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  modalLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    letterSpacing: 2,
    marginBottom: 8,
  },
  input: {
    backgroundColor: colors.backgroundSecondary,
    borderWidth: 1,
    borderColor: colors.neonBlue,
    borderRadius: 12,
    padding: 16,
    fontSize: 24,
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: 16,
  },
  xpPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 12,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    marginBottom: 16,
  },
  xpPreviewText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.neonBlue,
  },
  logButton: {
    backgroundColor: colors.neonBlue,
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  logButtonDisabled: {
    opacity: 0.6,
  },
  logButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  levelUpOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.95)',
  },
  levelUpContent: {
    padding: 48,
    borderRadius: 24,
    alignItems: 'center',
    borderWidth: 3,
    borderColor: colors.neonBlue,
  },
  levelUpText: {
    fontSize: 36,
    fontWeight: 'bold',
    color: colors.neonBlue,
    letterSpacing: 6,
    marginBottom: 16,
  },
  levelUpNumber: {
    fontSize: 96,
    fontWeight: 'bold',
    color: colors.neonPurple,
  },
  levelUpSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    letterSpacing: 3,
    marginTop: 16,
  },
});
