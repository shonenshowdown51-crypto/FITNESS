import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/contexts/AuthContext';
import { colors, EXERCISE_NAMES } from '@/constants/theme';
import { Target, CircleCheck as CheckCircle, Circle, Plus, RefreshCw } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface Quest {
  id: string;
  exercise_type: string;
  target_quantity: number;
  current_progress: number;
  completed: boolean;
  xp_reward: number;
}

export default function QuestsScreen() {
  const { profile } = useAuth();
  const [quests, setQuests] = useState<Quest[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchQuests = async () => {
    if (!profile) return;

    try {
      const today = new Date().toISOString().split('T')[0];

      const { data, error } = await supabase
        .from('daily_quests')
        .select('*')
        .eq('user_id', profile.id)
        .eq('quest_date', today);

      if (error) throw error;

      if (!data || data.length === 0) {
        await generateDailyQuests();
      } else {
        setQuests(data);
      }
    } catch (error) {
      console.error('Error fetching quests:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const generateDailyQuests = async () => {
    if (!profile) return;

    try {
      const today = new Date().toISOString().split('T')[0];

      const questTemplates = [
        { exercise_type: 'push_ups', target_quantity: 30, xp_reward: 200 },
        { exercise_type: 'sit_ups', target_quantity: 40, xp_reward: 200 },
        { exercise_type: 'plank', target_quantity: 60, xp_reward: 150 },
      ];

      const questsToInsert = questTemplates.map((template) => ({
        user_id: profile.id,
        quest_date: today,
        ...template,
      }));

      const { data, error } = await supabase
        .from('daily_quests')
        .insert(questsToInsert)
        .select();

      if (error) throw error;

      if (data) {
        setQuests(data);
      }
    } catch (error) {
      console.error('Error generating quests:', error);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchQuests();
  };

  useEffect(() => {
    fetchQuests();
  }, [profile]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.neonBlue} />
      </View>
    );
  }

  const completedQuests = quests.filter((q) => q.completed).length;
  const totalQuests = quests.length;
  const completionPercentage = totalQuests > 0 ? (completedQuests / totalQuests) * 100 : 0;

  return (
    <LinearGradient colors={[colors.background, colors.backgroundSecondary]} style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.neonBlue} />}>
        <View style={styles.header}>
          <Target size={32} color={colors.neonPurple} />
          <Text style={styles.headerTitle}>DAILY QUESTS</Text>
        </View>

        <View style={styles.progressCard}>
          <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.progressGradient}>
            <Text style={styles.progressTitle}>TODAY'S PROGRESS</Text>
            <View style={styles.progressBarContainer}>
              <View style={styles.progressBar}>
                <LinearGradient
                  colors={[colors.neonBlue, colors.neonPurple]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[styles.progressFill, { width: `${completionPercentage}%` }]}
                />
              </View>
              <Text style={styles.progressText}>
                {completedQuests} / {totalQuests} Completed
              </Text>
            </View>
          </LinearGradient>
        </View>

        {quests.length === 0 ? (
          <View style={styles.emptyState}>
            <Target size={64} color={colors.textSecondary} />
            <Text style={styles.emptyText}>No quests available today</Text>
            <TouchableOpacity style={styles.generateButton} onPress={generateDailyQuests}>
              <Plus size={20} color={colors.background} />
              <Text style={styles.generateButtonText}>GENERATE QUESTS</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.questsList}>
            <Text style={styles.sectionTitle}>AVAILABLE QUESTS</Text>
            {quests.map((quest) => {
              const progress = (quest.current_progress / quest.target_quantity) * 100;
              return (
                <View key={quest.id} style={styles.questCard}>
                  <LinearGradient
                    colors={
                      quest.completed
                        ? [colors.card, colors.cardHighlight]
                        : [colors.card, colors.cardHighlight]
                    }
                    style={[styles.questGradient, quest.completed && styles.questCompleted]}>
                    <View style={styles.questHeader}>
                      <View style={styles.questInfo}>
                        {quest.completed ? (
                          <CheckCircle size={24} color={colors.success} />
                        ) : (
                          <Circle size={24} color={colors.textSecondary} />
                        )}
                        <Text style={[styles.questName, quest.completed && styles.questNameCompleted]}>
                          {EXERCISE_NAMES[quest.exercise_type as keyof typeof EXERCISE_NAMES]}
                        </Text>
                      </View>
                      <View style={styles.rewardBadge}>
                        <Text style={styles.rewardText}>+{quest.xp_reward} XP</Text>
                      </View>
                    </View>

                    <Text style={styles.questTarget}>
                      Target: {quest.target_quantity} {quest.exercise_type === 'plank' ? 'seconds' : 'reps'}
                    </Text>

                    <View style={styles.questProgressContainer}>
                      <View style={styles.questProgressBar}>
                        <LinearGradient
                          colors={quest.completed ? [colors.success, colors.success] : [colors.neonBlue, colors.neonPurple]}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 0 }}
                          style={[styles.questProgressFill, { width: `${Math.min(progress, 100)}%` }]}
                        />
                      </View>
                      <Text style={styles.questProgressText}>
                        {quest.current_progress} / {quest.target_quantity}
                      </Text>
                    </View>

                    {quest.completed && (
                      <View style={styles.completedBanner}>
                        <CheckCircle size={16} color={colors.success} />
                        <Text style={styles.completedText}>QUEST COMPLETED</Text>
                      </View>
                    )}
                  </LinearGradient>
                </View>
              );
            })}
          </View>
        )}

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>How Quests Work</Text>
          <Text style={styles.infoText}>
            Complete daily quests to earn bonus XP and level up faster! Quests reset every day at midnight. Track your progress by logging exercises in the Train tab.
          </Text>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    letterSpacing: 2,
  },
  progressCard: {
    marginBottom: 24,
  },
  progressGradient: {
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.neonPurple,
  },
  progressTitle: {
    fontSize: 12,
    color: colors.textSecondary,
    letterSpacing: 2,
    marginBottom: 16,
  },
  progressBarContainer: {
    gap: 8,
  },
  progressBar: {
    height: 16,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 8,
  },
  progressText: {
    fontSize: 14,
    color: colors.textPrimary,
    textAlign: 'center',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 16,
    marginBottom: 24,
  },
  generateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.neonPurple,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  generateButtonText: {
    color: colors.background,
    fontSize: 14,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  questsList: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 14,
    color: colors.textSecondary,
    letterSpacing: 3,
    marginBottom: 16,
    fontWeight: 'bold',
  },
  questCard: {
    marginBottom: 16,
  },
  questGradient: {
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  questCompleted: {
    borderColor: colors.success,
    opacity: 0.8,
  },
  questHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  questInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  questName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  questNameCompleted: {
    color: colors.success,
  },
  rewardBadge: {
    backgroundColor: colors.neonBlue,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  rewardText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.background,
  },
  questTarget: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 12,
  },
  questProgressContainer: {
    gap: 8,
  },
  questProgressBar: {
    height: 12,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 6,
    overflow: 'hidden',
  },
  questProgressFill: {
    height: '100%',
    borderRadius: 6,
  },
  questProgressText: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'right',
  },
  completedBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: colors.success,
  },
  completedText: {
    fontSize: 12,
    color: colors.success,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.neonPurple,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 12,
  },
  infoText: {
    fontSize: 14,
    color: colors.textSecondary,
    lineHeight: 20,
  },
});
