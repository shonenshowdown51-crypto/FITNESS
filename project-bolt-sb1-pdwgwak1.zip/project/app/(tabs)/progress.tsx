import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '@/contexts/AuthContext';
import { colors, EXERCISE_NAMES } from '@/constants/theme';
import { TrendingUp, Award, Calendar, Zap, Trophy } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';

interface UserStats {
  total_push_ups: number;
  total_pull_ups: number;
  total_sit_ups: number;
  total_leg_raises: number;
  total_plank_seconds: number;
}

interface Achievement {
  id: string;
  achievement_type: string;
  title: string;
  description: string;
  icon: string;
  earned_at: string;
}

export default function ProgressScreen() {
  const { profile } = useAuth();
  const [stats, setStats] = useState<UserStats | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    if (!profile) return;

    try {
      const { data: statsData, error: statsError } = await supabase
        .from('user_stats')
        .select('*')
        .eq('user_id', profile.id)
        .maybeSingle();

      if (statsError) throw statsError;
      setStats(statsData);

      const { data: achievementsData, error: achievementsError } = await supabase
        .from('achievements')
        .select('*')
        .eq('user_id', profile.id)
        .order('earned_at', { ascending: false });

      if (achievementsError) throw achievementsError;
      setAchievements(achievementsData || []);
    } catch (error) {
      console.error('Error fetching progress data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  useEffect(() => {
    fetchData();
  }, [profile]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.neonBlue} />
      </View>
    );
  }

  const totalExercises = stats
    ? stats.total_push_ups +
      stats.total_pull_ups +
      stats.total_sit_ups +
      stats.total_leg_raises
    : 0;

  return (
    <LinearGradient colors={[colors.background, colors.backgroundSecondary]} style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.neonBlue} />}>
        <View style={styles.header}>
          <TrendingUp size={32} color={colors.neonBlue} />
          <Text style={styles.headerTitle}>PROGRESS</Text>
        </View>

        <View style={styles.summaryCard}>
          <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.summaryGradient}>
            <View style={styles.summaryRow}>
              <View style={styles.summaryItem}>
                <Zap size={24} color={colors.neonBlue} />
                <Text style={styles.summaryValue}>{profile?.level}</Text>
                <Text style={styles.summaryLabel}>LEVEL</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <Calendar size={24} color={colors.warning} />
                <Text style={styles.summaryValue}>{profile?.daily_streak}</Text>
                <Text style={styles.summaryLabel}>STREAK</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <Trophy size={24} color={colors.neonPurple} />
                <Text style={styles.summaryValue}>{achievements.length}</Text>
                <Text style={styles.summaryLabel}>BADGES</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        <Text style={styles.sectionTitle}>WORKOUT STATISTICS</Text>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.statGradient}>
              <Text style={styles.statEmoji}>💪</Text>
              <Text style={styles.statValue}>{stats?.total_push_ups || 0}</Text>
              <Text style={styles.statLabel}>Push-ups</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.statGradient}>
              <Text style={styles.statEmoji}>🏋️</Text>
              <Text style={styles.statValue}>{stats?.total_pull_ups || 0}</Text>
              <Text style={styles.statLabel}>Pull-ups</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.statGradient}>
              <Text style={styles.statEmoji}>🧘</Text>
              <Text style={styles.statValue}>{stats?.total_sit_ups || 0}</Text>
              <Text style={styles.statLabel}>Sit-ups</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.statGradient}>
              <Text style={styles.statEmoji}>🦵</Text>
              <Text style={styles.statValue}>{stats?.total_leg_raises || 0}</Text>
              <Text style={styles.statLabel}>Leg Raises</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.statGradient}>
              <Text style={styles.statEmoji}>⏱️</Text>
              <Text style={styles.statValue}>{stats?.total_plank_seconds || 0}s</Text>
              <Text style={styles.statLabel}>Plank</Text>
            </LinearGradient>
          </View>

          <View style={styles.statCard}>
            <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.statGradient}>
              <Text style={styles.statEmoji}>📊</Text>
              <Text style={styles.statValue}>{totalExercises}</Text>
              <Text style={styles.statLabel}>Total Reps</Text>
            </LinearGradient>
          </View>
        </View>

        <Text style={styles.sectionTitle}>ACHIEVEMENTS</Text>

        {achievements.length === 0 ? (
          <View style={styles.emptyState}>
            <Award size={64} color={colors.textSecondary} />
            <Text style={styles.emptyText}>No achievements yet</Text>
            <Text style={styles.emptySubtext}>Keep training to unlock badges!</Text>
          </View>
        ) : (
          <View style={styles.achievementsList}>
            {achievements.map((achievement) => (
              <View key={achievement.id} style={styles.achievementCard}>
                <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.achievementGradient}>
                  <View style={styles.achievementIcon}>
                    <Text style={styles.achievementEmoji}>{achievement.icon}</Text>
                  </View>
                  <View style={styles.achievementInfo}>
                    <Text style={styles.achievementTitle}>{achievement.title}</Text>
                    <Text style={styles.achievementDescription}>{achievement.description}</Text>
                    <Text style={styles.achievementDate}>
                      Earned: {new Date(achievement.earned_at).toLocaleDateString()}
                    </Text>
                  </View>
                </LinearGradient>
              </View>
            ))}
          </View>
        )}

        <View style={styles.milestoneCard}>
          <LinearGradient colors={[colors.card, colors.cardHighlight]} style={styles.milestoneGradient}>
            <Text style={styles.milestoneTitle}>NEXT MILESTONE</Text>
            <Text style={styles.milestoneText}>
              Reach Level {(profile?.level || 0) + 1} to unlock new achievements!
            </Text>
            <View style={styles.milestoneProgress}>
              <Text style={styles.milestoneXP}>
                {profile?.current_xp} / {(profile?.level || 0) * 100} XP
              </Text>
            </View>
          </LinearGradient>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    letterSpacing: 2,
  },
  summaryCard: {
    marginBottom: 24,
  },
  summaryGradient: {
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  summaryItem: {
    alignItems: 'center',
    gap: 8,
  },
  summaryDivider: {
    width: 1,
    height: 60,
    backgroundColor: colors.textSecondary,
    opacity: 0.3,
  },
  summaryValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.textPrimary,
  },
  summaryLabel: {
    fontSize: 10,
    color: colors.textSecondary,
    letterSpacing: 2,
  },
  sectionTitle: {
    fontSize: 14,
    color: colors.textSecondary,
    letterSpacing: 3,
    marginBottom: 16,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 32,
  },
  statCard: {
    width: '48%',
  },
  statGradient: {
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neonBlue,
  },
  statEmoji: {
    fontSize: 32,
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 18,
    color: colors.textSecondary,
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    opacity: 0.7,
  },
  achievementsList: {
    gap: 12,
    marginBottom: 24,
  },
  achievementCard: {},
  achievementGradient: {
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    borderWidth: 1,
    borderColor: colors.neonPurple,
  },
  achievementIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.backgroundSecondary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.neonPurple,
  },
  achievementEmoji: {
    fontSize: 32,
  },
  achievementInfo: {
    flex: 1,
  },
  achievementTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  achievementDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 6,
  },
  achievementDate: {
    fontSize: 11,
    color: colors.neonPurple,
  },
  milestoneCard: {
    marginBottom: 24,
  },
  milestoneGradient: {
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.neonPurple,
  },
  milestoneTitle: {
    fontSize: 12,
    color: colors.textSecondary,
    letterSpacing: 2,
    marginBottom: 12,
  },
  milestoneText: {
    fontSize: 16,
    color: colors.textPrimary,
    textAlign: 'center',
    marginBottom: 16,
  },
  milestoneProgress: {
    width: '100%',
  },
  milestoneXP: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.neonBlue,
    textAlign: 'center',
  },
});
