export const colors = {
  background: '#0a0a0f',
  backgroundSecondary: '#14141f',
  card: '#1a1a2e',
  cardHighlight: '#20203a',
  neonBlue: '#00d4ff',
  neonPurple: '#a855f7',
  neonPink: '#e879f9',
  textPrimary: '#ffffff',
  textSecondary: '#a0a0b8',
  success: '#00ff88',
  warning: '#ffaa00',
  danger: '#ff3366',
  shadow: 'rgba(0, 212, 255, 0.3)',
  glowBlue: 'rgba(0, 212, 255, 0.5)',
  glowPurple: 'rgba(168, 85, 247, 0.5)',
};

export const EXERCISE_XP = {
  push_ups: 5,
  pull_ups: 10,
  sit_ups: 5,
  leg_raises: 6,
  plank: 1,
};

export const EXERCISE_NAMES = {
  push_ups: 'Push-ups',
  pull_ups: 'Pull-ups',
  sit_ups: 'Sit-ups',
  leg_raises: 'Leg Raises',
  plank: 'Plank',
};

export const calculateXPForLevel = (level: number): number => {
  return level * 100;
};

export const calculateLevel = (totalXP: number): { level: number; currentXP: number } => {
  let level = 1;
  let remainingXP = totalXP;

  while (remainingXP >= calculateXPForLevel(level)) {
    remainingXP -= calculateXPForLevel(level);
    level++;
  }

  return { level, currentXP: remainingXP };
};
