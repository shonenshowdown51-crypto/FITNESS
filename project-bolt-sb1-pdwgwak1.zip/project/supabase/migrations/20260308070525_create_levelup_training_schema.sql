/*
  # LevelUp Training Database Schema

  ## Overview
  Creates the complete database structure for the LevelUp Training gamified fitness app.

  ## Tables Created
  
  ### 1. profiles
  - `id` (uuid, primary key): Links to auth.users
  - `username` (text): User's display name
  - `level` (integer): Current character level (default: 1)
  - `current_xp` (integer): XP progress in current level (default: 0)
  - `total_xp` (integer): Lifetime total XP earned (default: 0)
  - `strength` (integer): Strength stat (default: 10)
  - `endurance` (integer): Endurance stat (default: 10)
  - `agility` (integer): Agility stat (default: 10)
  - `daily_streak` (integer): Consecutive days trained (default: 0)
  - `last_activity_date` (date): Last workout date for streak tracking
  - `music_enabled` (boolean): Background music preference (default: true)
  - `created_at` (timestamptz): Account creation timestamp
  - `updated_at` (timestamptz): Last profile update timestamp

  ### 2. exercises_log
  - `id` (uuid, primary key): Unique log entry ID
  - `user_id` (uuid, foreign key): References profiles.id
  - `exercise_type` (text): Type of exercise (push_ups, pull_ups, sit_ups, leg_raises, plank)
  - `quantity` (integer): Number of reps or seconds completed
  - `xp_earned` (integer): XP awarded for this exercise
  - `completed_at` (timestamptz): When the exercise was completed

  ### 3. daily_quests
  - `id` (uuid, primary key): Unique quest ID
  - `user_id` (uuid, foreign key): References profiles.id
  - `quest_date` (date): Date the quest is for
  - `exercise_type` (text): Required exercise type
  - `target_quantity` (integer): Goal amount to complete
  - `current_progress` (integer): Current progress toward goal (default: 0)
  - `completed` (boolean): Whether quest is completed (default: false)
  - `xp_reward` (integer): Bonus XP for completion
  - `created_at` (timestamptz): Quest creation timestamp

  ### 4. achievements
  - `id` (uuid, primary key): Unique achievement ID
  - `user_id` (uuid, foreign key): References profiles.id
  - `achievement_type` (text): Type of achievement earned
  - `title` (text): Achievement display title
  - `description` (text): Achievement description
  - `icon` (text): Icon identifier for the badge
  - `earned_at` (timestamptz): When achievement was unlocked

  ### 5. user_stats
  - `id` (uuid, primary key): Unique stats entry ID
  - `user_id` (uuid, foreign key): References profiles.id
  - `total_push_ups` (integer): Lifetime push-up count (default: 0)
  - `total_pull_ups` (integer): Lifetime pull-up count (default: 0)
  - `total_sit_ups` (integer): Lifetime sit-up count (default: 0)
  - `total_leg_raises` (integer): Lifetime leg raise count (default: 0)
  - `total_plank_seconds` (integer): Lifetime plank time in seconds (default: 0)
  - `updated_at` (timestamptz): Last stats update

  ## Security
  - Row Level Security (RLS) enabled on all tables
  - Users can only read and modify their own data
  - Authenticated access required for all operations

  ## Important Notes
  - XP calculation: Level up requires (level * 100) XP
  - Stats increase by 1 every 5 levels
  - Daily quests reset at midnight UTC
  - Streak breaks if no activity for 24+ hours
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  level integer DEFAULT 1 NOT NULL,
  current_xp integer DEFAULT 0 NOT NULL,
  total_xp integer DEFAULT 0 NOT NULL,
  strength integer DEFAULT 10 NOT NULL,
  endurance integer DEFAULT 10 NOT NULL,
  agility integer DEFAULT 10 NOT NULL,
  daily_streak integer DEFAULT 0 NOT NULL,
  last_activity_date date,
  music_enabled boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create exercises_log table
CREATE TABLE IF NOT EXISTS exercises_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  exercise_type text NOT NULL CHECK (exercise_type IN ('push_ups', 'pull_ups', 'sit_ups', 'leg_raises', 'plank')),
  quantity integer NOT NULL CHECK (quantity > 0),
  xp_earned integer NOT NULL CHECK (xp_earned >= 0),
  completed_at timestamptz DEFAULT now() NOT NULL
);

-- Create daily_quests table
CREATE TABLE IF NOT EXISTS daily_quests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  quest_date date DEFAULT CURRENT_DATE NOT NULL,
  exercise_type text NOT NULL CHECK (exercise_type IN ('push_ups', 'pull_ups', 'sit_ups', 'leg_raises', 'plank')),
  target_quantity integer NOT NULL CHECK (target_quantity > 0),
  current_progress integer DEFAULT 0 NOT NULL CHECK (current_progress >= 0),
  completed boolean DEFAULT false NOT NULL,
  xp_reward integer NOT NULL CHECK (xp_reward >= 0),
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, quest_date, exercise_type)
);

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  achievement_type text NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  earned_at timestamptz DEFAULT now() NOT NULL
);

-- Create user_stats table
CREATE TABLE IF NOT EXISTS user_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE UNIQUE NOT NULL,
  total_push_ups integer DEFAULT 0 NOT NULL,
  total_pull_ups integer DEFAULT 0 NOT NULL,
  total_sit_ups integer DEFAULT 0 NOT NULL,
  total_leg_raises integer DEFAULT 0 NOT NULL,
  total_plank_seconds integer DEFAULT 0 NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_exercises_log_user_id ON exercises_log(user_id);
CREATE INDEX IF NOT EXISTS idx_exercises_log_completed_at ON exercises_log(completed_at);
CREATE INDEX IF NOT EXISTS idx_daily_quests_user_date ON daily_quests(user_id, quest_date);
CREATE INDEX IF NOT EXISTS idx_achievements_user_id ON achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_user_stats_user_id ON user_stats(user_id);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE exercises_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_quests ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_stats ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- RLS Policies for exercises_log
CREATE POLICY "Users can view own exercises"
  ON exercises_log FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own exercises"
  ON exercises_log FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for daily_quests
CREATE POLICY "Users can view own quests"
  ON daily_quests FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own quests"
  ON daily_quests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own quests"
  ON daily_quests FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for achievements
CREATE POLICY "Users can view own achievements"
  ON achievements FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own achievements"
  ON achievements FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for user_stats
CREATE POLICY "Users can view own stats"
  ON user_stats FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own stats"
  ON user_stats FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own stats"
  ON user_stats FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);