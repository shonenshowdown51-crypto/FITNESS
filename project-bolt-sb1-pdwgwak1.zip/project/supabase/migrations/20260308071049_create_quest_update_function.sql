/*
  # Create Quest Progress Update Function

  ## Overview
  Creates a PostgreSQL function to automatically update daily quest progress when exercises are logged.

  ## Function: update_quest_progress
  
  ### Parameters
  - `p_user_id` (uuid): The user's ID
  - `p_exercise_type` (text): Type of exercise completed
  - `p_quantity` (integer): Quantity of exercise completed

  ### Behavior
  - Finds matching daily quests for today
  - Increments quest progress
  - Marks quest as completed if target reached
  - Awards bonus XP when quest is completed

  ### Returns
  - void

  ## Security
  - Function runs with caller's privileges
  - Respects existing RLS policies
*/

CREATE OR REPLACE FUNCTION update_quest_progress(
  p_user_id uuid,
  p_exercise_type text,
  p_quantity integer
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_quest_id uuid;
  v_target_quantity integer;
  v_current_progress integer;
  v_xp_reward integer;
  v_completed boolean;
  v_new_progress integer;
BEGIN
  SELECT id, target_quantity, current_progress, xp_reward, completed
  INTO v_quest_id, v_target_quantity, v_current_progress, v_xp_reward, v_completed
  FROM daily_quests
  WHERE user_id = p_user_id
    AND exercise_type = p_exercise_type
    AND quest_date = CURRENT_DATE
    AND completed = false
  LIMIT 1;

  IF v_quest_id IS NOT NULL THEN
    v_new_progress := v_current_progress + p_quantity;
    
    IF v_new_progress >= v_target_quantity THEN
      UPDATE daily_quests
      SET current_progress = v_target_quantity,
          completed = true
      WHERE id = v_quest_id;
      
      UPDATE profiles
      SET total_xp = total_xp + v_xp_reward,
          current_xp = current_xp + v_xp_reward
      WHERE id = p_user_id;
    ELSE
      UPDATE daily_quests
      SET current_progress = v_new_progress
      WHERE id = v_quest_id;
    END IF;
  END IF;
END;
$$;